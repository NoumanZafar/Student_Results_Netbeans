/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package combineProject;

/**
 *
 * @author Nouman
 */
public class moduleClass {
    private String module_code;
    private String module_name;
    private int ects;
    
    public moduleClass(){
        super();
    }
    public moduleClass(String module_code,String module_name,int ects){
        this.module_code=module_code;
        this.module_name=module_name;
        this.ects=ects;
    }
    public void setModuleCode(String module_code){
        this.module_code=module_code;
    }
    public String getModuleCode(){
        return this.module_code;
    }
    public void setModuleName(String module_name){
        this.module_name=module_name;
    }
    public String getModuleName(){
        return this.module_name;
    }
    public void setEcts(int ects){
        this.ects=ects;
    }
    public int getEcts(){
        return this.ects;
    }
}
