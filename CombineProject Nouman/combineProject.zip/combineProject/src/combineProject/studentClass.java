/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package combineProject;

/**
 *
 * @author Nouman
 */
public class studentClass extends personClass{
    private String studentId;
    private String groupId;
    
    public studentClass(){
        super();
    }
    public studentClass(String studentId,String groupId){
        super();
        this.studentId=studentId;
        this.groupId=groupId;
    }
    public void setStudentId(String studentId){
        this.studentId=studentId;
    }
    public String getStudentId(){
        return this.studentId;
    }
    public void setGroupId(String groupId){
        this.groupId=groupId;
    }
    public String getGroupId(){
        return this.groupId;
    }
}
