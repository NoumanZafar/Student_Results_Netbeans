/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package combineProject;



/**
 *
 * @author Nouman
 */
public class teacherClass extends personClass {

    private String teacher_id;
    private String logIn_password;

    public teacherClass() {
        super();
    }

    public teacherClass(String teacher_id, String logIn_password) {
        super();
        this.teacher_id = teacher_id;
        this.logIn_password = logIn_password;
    }

    public void setTeacherId(String teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getTeacherId() {
        return this.teacher_id;
    }

    public void setLogInPassword(String logIn_password) {
        this.logIn_password = logIn_password;
    }

    public String getLogInOassword() {
        return this.logIn_password;
    }

}
