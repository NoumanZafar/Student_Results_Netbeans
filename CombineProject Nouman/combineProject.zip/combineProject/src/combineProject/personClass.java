/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package combineProject;

import java.sql.Date;

/**
 *
 * @author Nouman
 */
public class personClass {

    private EnumTitle title;
    private String first_name;
    private String last_name;
    private String address_1;
    private String address_2;
    private String city;
    private String nationality;
    private Date dob;
    private EnumGender gender;
    private String email;
    private String telephone_number;

    public personClass() {
        super();
    }

    public personClass(EnumTitle title, EnumGender gender) {
        super();
        this.title = title;
        this.gender = gender;
    }

    public void setTitle(EnumTitle title) {
        this.title = title;
    }

    public EnumTitle getTitle() {
        return this.title;
    }

    public void setFname(String first_name) {
        this.first_name = first_name;
    }

    public String getFname() {
        return this.first_name;
    }

    public void setLname(String last_name) {
        this.last_name = last_name;
    }

    public String getLname() {
        return this.last_name;
    }

    public void setAddress1(String address_1) {
        this.address_1 = address_1;
    }

    public String getAddress1() {
        return this.address_1;
    }

    public void setAddress2(String address_2) {
        this.address_2 = address_2;
    }

    public String getAddress2() {
        return this.address_2;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCity() {
        return this.city;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getNationality() {
        return this.nationality;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public Date getDob() {
        return this.dob;
    }

    public void setGender(EnumGender gender) {
        this.gender = gender;
    }

    public EnumGender getGender() {
        return this.gender;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return this.email;
    }

    public void setTelephone(String telephone_number) {
        this.telephone_number = telephone_number;
    }

    public String getTelephone() {
        return this.telephone_number;
    }
}
