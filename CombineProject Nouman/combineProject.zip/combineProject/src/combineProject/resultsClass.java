/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package combineProject;

import javax.swing.JOptionPane;

/**
 *
 * @author Nouman
 */
public class resultsClass {

    private String module_code;
    private String student_id;
    private double assessment_1;
    private double assessment_2;
    private double assessment_3;
    private double assessment_4;
    private double exam;

    public resultsClass() {
        super();
    }

    public resultsClass(String module_code, String student_id, double assessment_1, double assessment_2, double assessment_3,
            double assessment_4, double exam) {
        super();
        this.module_code = module_code;
        this.student_id = student_id;
        this.assessment_1 = assessment_1;
        this.assessment_2 = assessment_2;
        this.assessment_3 = assessment_3;
        this.assessment_4 = assessment_4;
        this.exam = exam;
    }

    public void setModuleCode(String module_code) {
        this.module_code = module_code;
    }

    public String getModuleCode() {
        return this.module_code;
    }

    public void setStudentId(String student_id) {
        this.student_id = student_id;
    }

    public String getStudentId() {
        return this.student_id;
    }

    public void setAssessment_1(double assessment_1) {
        this.assessment_1 = assessment_1;
    }

    public double getAssessment_1() {
        return this.assessment_1;
    }

    public void setAssessment_2(double assessment_2) {
        this.assessment_2 = assessment_2;
    }

    public double getAssessment_2() {
        return this.assessment_2;
    }

    public void setAssessment_3(double assessment_3) {
        this.assessment_3 = assessment_3;
    }

    public double getAssessment_3() {
        return this.assessment_3;
    }

    public void setAssessment_4(double assessment_4) {
        this.assessment_4 = assessment_4;
    }

    public double getAssessment_4() {
        return this.assessment_4;
    }

    public void setExam(double exam) {
        this.exam = exam;
    }

    public double getExam() {
        return this.exam;
    }
}
