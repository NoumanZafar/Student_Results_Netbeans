/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package combineProject;

/**
 *
 * @author Nouman
 */
public class programClass {

    private String prog_code;
    private String prog_name;
    private int duration;
    private double fees;
    private int nfq_level;
    private int total_ects;
    private EnumClass full_time;
    
    public programClass(){
        super();
    }

    public programClass(String prog_code, String prog_name, int duration, double fees, int nfq_level, int total_ects, EnumClass full_time) {
        this.prog_code = prog_code;
        this.prog_name = prog_name;
        this.duration = duration;
        this.fees = fees;
        this.nfq_level = nfq_level;
        this.total_ects = total_ects;
        this.full_time = full_time;
    }

    public void setProg_code(String prog_code) {
        this.prog_code = prog_code;
    }

    public String getProg_code() {
        return this.prog_code;
    }

    public void setProg_name(String prog_name) {
        this.prog_name = prog_name;
    }

    public String getProg_name() {
        return this.prog_name;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getDuration() {
        return this.duration;
    }

    public void setFees(double fees) {
        this.fees = fees;
    }

    public double getFees() {
        return this.fees;
    }

    public void setNfq_level(int nfq_level) {
        this.nfq_level = nfq_level;
    }

    public int getNfq_level() {
        return this.nfq_level;
    }

    public void setTotal_ects(int total_ects) {
        this.total_ects = total_ects;
    }

    public int getTotal_ects() {
        return this.total_ects;
    }
    public void setFullTime(EnumClass full_time){
        this.full_time=full_time;
    }
    public EnumClass getFullTime(){
        return full_time;
    }
    
    public static void digitValidation(java.awt.event.KeyEvent evt){
        char key=evt.getKeyChar();
        if(!(Character.isDigit(key))){            
            evt.consume();
        }
    }
}
